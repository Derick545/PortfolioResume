-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 03, 2023 at 04:36 PM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
CREATE TABLE IF NOT EXISTS `projects` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `Title` varchar(250) NOT NULL,
  `IDE` varchar(250) NOT NULL,
  `GIT` varchar(250) NOT NULL,
  `Type` varchar(250) DEFAULT NULL,
  `OS` varchar(250) DEFAULT NULL,
  `Description` text,
  `Additional` text,
  `Logo` varbinary(10000) DEFAULT NULL,
  `Language` varchar(250) DEFAULT NULL,
  `FrontLanguage` varchar(250) DEFAULT NULL,
  `Video` blob,
  `MyApp` varbinary(12000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `Title`, `IDE`, `GIT`, `Type`, `OS`, `Description`, `Additional`, `Logo`, `Language`, `FrontLanguage`, `Video`, `MyApp`) VALUES
(1, 'Sony', 'Android Studio', 'http/www.zonkewap.com ', 'Website', 'Windows', 'jkda,dsasd sdas ds ad ad as da sd as da sd as d sa,dnsakldjklajfdsa kfjdsklfjldkjflkads;jf a;gjlfkj gfkljgklfjglkajgkljsdklfjdskljfkl ds;jfdkl;sjfklads jfkladjsfkl; aldkjf lkdfjkljfkldsjflkajdfkljsdfkljdklfjakldsjflkdsjklfjakljfkljsdfkljdskljflkdsjfhkdslhg,mdsngkldjflkdsjfalksdjfn,dmsnfoewnfldnfldskfjn,mdsnafndkjfldms,fndkl fkjds klfjldsk flkdjfkljdsklfj dskljfkldsjfkl ddslkjfkldsj flkdsjf kllsdkjflkds flkjdskljfkldsjflkdsjflk dslkjflkadsjflkjdklafjklds;jf;dsljkfkldsj fkldjf lkdsjfkla;jkdlfj adskljfkldjfkldsjf lkdjflkdjsfkljdsl', 'CSS,HTML, ', 0x30, '', '', '', ''),
(2, '', '', '', '', '', '', '', '', '', '', '', ''),
(3, 'Tedek', 'Netbeans', 'https://www.flaticon.com/search?word=upload%20file', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Tedek', 'Netbeans', 'https://www.flaticon.com/search?word=upload%20file', NULL, NULL, NULL, 'Script', NULL, NULL, NULL, NULL, NULL),
(5, 'Tedek', 'Netbeans', 'https://www.flaticon.com/search?word=upload%20file', NULL, NULL, NULL, 'Script', NULL, 'Javascript', NULL, NULL, NULL),
(6, 'Tedek', 'Netbeans', 'https://www.flaticon.com/search?word=upload%20file', 'Mobile', 'Windows', NULL, 'Script', NULL, 'C#', NULL, NULL, NULL),
(7, 'Tedek', 'Netbeans', 'https://www.flaticon.com/search?word=upload%20file', 'Desktop', 'Cross-Platform', 'nmbmnbmnbmnbmnbmn', 'https://www.flaticon.com/search?word=upload%20file', '', 'Javascript', 'Javascript', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `testtbl`
--

DROP TABLE IF EXISTS `testtbl`;
CREATE TABLE IF NOT EXISTS `testtbl` (
  `Title` varchar(250) NOT NULL,
  `IDE` varchar(250) NOT NULL,
  `GIT` varchar(250) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `testtbl`
--

INSERT INTO `testtbl` (`Title`, `IDE`, `GIT`) VALUES
('Tedek', 'Netbeans', 'Tedek');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`) VALUES
(1, 'Derick', '339218De*/');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
